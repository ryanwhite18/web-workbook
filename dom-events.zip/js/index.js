// when the document is done loading, run the script inside
alert("Are you ready to count by ones, tens, and hundred?")
$(document).ready(function() {
  var num = 0;
  $('#counter-1').click(function() {
    num++;
    $(this).text(num);
  })
  
   $('#counter-10').click(   

function(){
 let numTwo = Number ($(this).text());
 numTwo +=10;
 $(this).text(numTwo);
 })

 $('#counter-100').click(   

    function(){
    let numThree = Number ($(this).text());
    numThree +=100;
    $(this).text(numThree);
    })

$('#counterClickAll').click(
  
function(){$('#counter-1, #counter-10, #counter-100').click();})
});